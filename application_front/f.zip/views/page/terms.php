<!--====== BANNER ==========-->
<section>
    <div class="rows inner_banner inner_banner_1">
        <div class="container">
            <h2><span>Terms & Condition</span> </h2>
            <ul>
                <li><a href="<?php echo base_url(); ?>">Home</a>
                </li>
                <li><i class="fa fa-angle-right" aria-hidden="true"></i> </li>
                <li><a href="#inner-page-title" class="bread-acti">Terms & Condition</a>
                </li>
            </ul>
        </div>
    </div>
</section>
<!--====== ALL TESTIMONIALS ==========-->
<section>
    <div class="rows inn-page-bg com-colo">
        <div class="container tb-space inn-page-con-bg pad-bot-redu" id="inner-page-title">
            <!-- TITLE & DESCRIPTION -->
            <div class="spe-title">
                <h2>Terms & <span>Condition</span></h2>
                <div class="title-line">
                    <div class="tl-1"></div>
                    <div class="tl-2"></div>
                    <div class="tl-3"></div>
                </div>
            </div>
            <div class="row tourb2-ab-p1">
				<div class="col-md-12 col-sm-12">
					<div class="tourb2-ab-p1-left">
						<h3>Lorem Ipsum</h3> <span>Duis pretium gravida nisi, ut pulvinar lorem bibendum eget</span>
						<p>Aliquam blandit nisl sem. Mauris quis enim purus. Vivamus nec tortor bibendum risus placerat vulputate at gravida ante. Nam sit amet tellus enim. Phasellus consectetur porttitor lobortis. Integer cursus odio at mattis porttitor. In hac habitasse platea dictumst. Nunc sit amet cursus felis. Etiam venenatis auctor metus, et lacinia elit dignissim non. Aenean auctor semper erat porta dictum.</p>
						<p>Fusce velit sem, vestibulum ac enim ut, tincidunt pretium augue. Vestibulum purus sapien, porttitor a porta faucibus, hendrerit eget enim.</p> </div>
				</div>
			</div>
        </div>
    </div>
</section>