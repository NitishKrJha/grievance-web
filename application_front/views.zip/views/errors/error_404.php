<div class="log-in-block">
  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <div class="ls-in-tab">
          <!-- Tab panes -->
           <img src="<?php echo CSS_IMAGES_JS_BASE_URL;?>images/error404.jpg" alt="" style="height:500px;width: 100%;">
        </div>
      </div>
    </div>
  </div>
</div>