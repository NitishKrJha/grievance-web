
<style>
	#local-media.video-popup-smallBx video{
		height:100px;
	}
	#local-media.video-popup-smallBx{
		top: 200px;
		right: 0;
	}
	#remote-media video{
		width:100%;
	}
	div#remote-media{
		position: relative;
		/*bottom: 20%;
    right: 0; */
	}
	#local-media.video-popup-smallBx video {
    height: 100px;
    width: 136px;
	}
</style>

<?php
$global_facebook = $this->functions->getGlobalInfo('global_facebook_url');
$global_twitter = $this->functions->getGlobalInfo('global_twitter_url');
$global_youtube_url = $this->functions->getGlobalInfo('global_youtube_url');
$global_linkedin_url = $this->functions->getGlobalInfo('global_linkdin_url');
$global_instagram_url = $this->functions->getGlobalInfo('global_instagram_url');
?>
<!--====== FOOTER 1 ==========-->
<section>
		<div class="rows">
				<div class="footer1 home_title tb-space">
						<div class="pla1 container">
								<!-- FOOTER OFFER 1 -->
								<div class="col-md-3 col-sm-6 col-xs-12">
										<div class="disco">
												<h3>30%<span>OFF</span></h3>
												<h4>Eiffel Tower,Rome</h4>
												<p>valid only for 24th Dec</p> <a href="booking.html">Book Now</a> </div>
								</div>
								<!-- FOOTER OFFER 2 -->
								<div class="col-md-3 col-sm-6 col-xs-12">
										<div class="disco1 disco">
												<h3>42%<span>OFF</span></h3>
												<h4>Colosseum,Burj Al Arab</h4>
												<p>valid only for 18th Nov</p> <a href="booking.html">Book Now</a> </div>
								</div>
								<!-- FOOTER MOST POPULAR VACATIONS -->
								<div class="col-md-6 col-sm-12 col-xs-12 foot-spec footer_places">
										<h4><span>Most Popular</span> Vacations</h4>
										<ul>
												<li><a href="tour-details.html">Angkor Wat</a> </li>
												<li><a href="tour-details.html">Buckingham Palace</a> </li>
												<li><a href="tour-details.html">High Line</a> </li>
												<li><a href="tour-details.html">Sagrada Família</a> </li>
												<li><a href="tour-details.html">Statue of Liberty </a> </li>
												<li><a href="tour-details.html">Notre Dame de Paris</a> </li>
												<li><a href="tour-details.html">Taj Mahal</a> </li>
												<li><a href="tour-details.html">The Louvre</a> </li>
												<li><a href="tour-details.html">Tate Modern, London</a> </li>
												<li><a href="tour-details.html">Gothic Quarter</a> </li>
												<li><a href="tour-details.html">Table Mountain</a> </li>
												<li><a href="tour-details.html">Bayon</a> </li>
												<li><a href="tour-details.html">Great Wall of China</a> </li>
												<li><a href="tour-details.html">Hermitage Museum</a> </li>
												<li><a href="tour-details.html">Yellowstone</a> </li>
												<li><a href="tour-details.html">Musée d'Orsay</a> </li>
										</ul>
								</div>
						</div>
				</div>
		</div>
</section>
<!--====== FOOTER 2 ==========-->
<section>
		<div class="rows">
				<div class="footer">
						<div class="container">
								<div class="foot-sec2">
										<div>
												<div class="row">
														<div class="col-sm-3 foot-spec foot-com">
																<h4><span>Holiday</span> Tour & Travels</h4>
																<p>World's leading tour and travels Booking website,Over 30,000 packages worldwide.</p>
														</div>
														<div class="col-sm-3 foot-spec foot-com">
																<h4><span>Address</span> & Contact Info</h4>
																<p>28800 Orchard Lake Road, Suite 180 Farmington Hills, U.S.A. Landmark : Next To Airport</p>
																<p> <span class="strong">Phone: </span> <span class="highlighted">+101-1231-1231</span> </p>
														</div>
														<div class="col-sm-3 col-md-3 foot-spec foot-com">
																<h4><span>SUPPORT</span> & HELP</h4>
																<ul class="two-columns">
																		<li> <a href="#">About Us</a> </li>
																		<li> <a href="#">FAQ</a> </li>
																		<li> <a href="#">Feedbacks</a> </li>
																		<li> <a href="#">Blog </a> </li>
																		<li> <a href="#">Use Cases</a> </li>
																		<li> <a href="#">Advertise us</a> </li>
																		<li> <a href="#">Discount</a> </li>
																		<li> <a href="#">Vacations</a> </li>
																		<li> <a href="#">Branding Offers </a> </li>
																		<li> <a href="#">Contact Us</a> </li>
																</ul>
														</div>
														<div class="col-sm-3 foot-social foot-spec foot-com">
																<h4><span>Follow</span> with us</h4>
																<p>Join the thousands of other There are many variations of passages of Lorem Ipsum available</p>
																<ul>
																		<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
																		<li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
																		<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
																		<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
																		<li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a> </li>
																</ul>
														</div>
												</div>
										</div>
								</div>
						</div>
				</div>
		</div>
</section>
<!--====== FOOTER - COPYRIGHT ==========-->
<section>
		<div class="rows copy">
				<div class="container">
						<p>Copyrights © 2018 Company Name. All Rights Reserved</p>
				</div>
		</div>
</section>
<section>
		<div class="icon-float">
				<ul>
						<li><a href="#" class="sh">1k <br> Share</a> </li>
						<li><a href="#" class="fb1"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
						<li><a href="#" class="gp1"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
						<li><a href="#" class="tw1"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
						<li><a href="#" class="li1"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
						<li><a href="#" class="wa1"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> </li>
						<li><a href="#" class="sh1"><i class="fa fa-envelope-o" aria-hidden="true"></i></a> </li>
				</ul>
		</div>
</section>

<script>
	function messagealert(title,text,type){
			new PNotify({
						title: title,
						text:  text,
						type:  type,
						styling: 'bootstrap3'
					});
	}
</script>
